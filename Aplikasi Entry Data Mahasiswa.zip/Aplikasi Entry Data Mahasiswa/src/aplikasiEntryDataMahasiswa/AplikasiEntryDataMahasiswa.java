package aplikasiEntryDataMahasiswa;

public class AplikasiEntryDataMahasiswa {

    public static void main(String[] args) {
        Form_Login lgn = new Form_Login();
        lgn.setVisible(true);
        lgn.setLocationRelativeTo(null);
    }
}
